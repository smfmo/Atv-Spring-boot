package com.seuprojeto.minhaaplicacaoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinhaAplicacaoWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MinhaAplicacaoWebApplication.class, args);
	}

}
